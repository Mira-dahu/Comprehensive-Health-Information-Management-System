#ifndef VACCINATIONDIALOG_H
#define VACCINATIONDIALOG_H

#include "runtime.h"
#include <QDialog>

namespace Ui
{
    class VaccinationDialog;
}

enum class VACCINATION_DIALOG
{
    CREATE,
    MODIFY,
    READONLY
};

class VaccinationDialog : public QDialog
{
    Q_OBJECT

public:
    explicit VaccinationDialog(const QString &id, const QString &user_id, VACCINATION_DIALOG mode, QWidget *parent = nullptr);
    ~VaccinationDialog();

private slots:
    void on_pushButton_clicked();

private:
    //下载数据
    void download();
    //上传数据
    void upload();
    //检测数据
    bool check();

private:
    Ui::VaccinationDialog *ui;
    QString id;
    QString user_id;
    VACCINATION_DIALOG mode;
};

#endif // VACCINATIONDIALOG_H
