#ifndef ROUTEDIALOG_H
#define ROUTEDIALOG_H

#include "runtime.h"
#include <QDialog>

namespace Ui
{
    class RouteDialog;
}

enum class ROUTE_DIALOG
{
    CREATE,
    MODIFY,
    READONLY
};

class RouteDialog : public QDialog
{
    Q_OBJECT

public:
    explicit RouteDialog(const QString &id, const QString &user_id, ROUTE_DIALOG mode, QWidget *parent = nullptr);
    ~RouteDialog();

private slots:
    void on_pushButton_clicked();

private:
    //下载数据
    void download();
    //上传数据
    void upload();
    //检测数据
    bool check();

private:
    Ui::RouteDialog *ui;
    QString id;
    QString user_id;
    ROUTE_DIALOG mode;
};

#endif // ROUTEDIALOG_H
