#include "netconfigdialog.h"
#include "ui_netconfigdialog.h"
#include <QMessageBox>

NetConfigDialog::NetConfigDialog(QWidget *parent) : QDialog(parent),
                                                    ui(new Ui::NetConfigDialog)
{
    ui->setupUi(this);
    ui->lineEditIP->setText(runtime.getConfig().host_ip);
    ui->lineEditPort->setText(QString::number(runtime.getConfig().host_port));
}

NetConfigDialog::~NetConfigDialog()
{
    delete ui;
}

void NetConfigDialog::on_pushButton_clicked()
{
    QString ip = ui->lineEditIP->text().trimmed();
    if (ip.isEmpty())
    {
        QMessageBox::warning(this, "提示", "请输入服务器地址");
        return;
    }
    QString port = ui->lineEditPort->text().trimmed();
    if (port.isEmpty())
    {
        QMessageBox::warning(this, "提示", "请输入服务器端口");
        return;
    }
    runtime.getConfig().host_ip = ip;
    runtime.getConfig().host_port = port.toInt();
    accept();
}
