#ifndef HEALTHDIALOG_H
#define HEALTHDIALOG_H

#include "runtime.h"
#include <QDialog>

namespace Ui
{
    class HealthDialog;
}

enum class HEALTH_DIALOG
{
    CREATE,
    MODIFY,
    READONLY
};

class HealthDialog : public QDialog
{
    Q_OBJECT

public:
    explicit HealthDialog(const QString &id, const QString &user_id, HEALTH_DIALOG mode, QWidget *parent = nullptr);
    ~HealthDialog();

private slots:
    void on_pushButton_clicked();

private:
    //下载数据
    void download();
    //上传数据
    void upload();
    //检测数据
    bool check();

private:
    Ui::HealthDialog *ui;
    QString id;
    QString user_id;
    HEALTH_DIALOG mode;
};

#endif // HEALTHDIALOG_H
