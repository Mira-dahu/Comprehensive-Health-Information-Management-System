#ifndef RUNTIME_H
#define RUNTIME_H

#include "dbmanager.h"
#include <QString>

enum class ROLE
{
    USER,
    ADMIN
};

class Context
{
public:
    Context(const QString &id, const QString &name, ROLE role)
        : id(id), name(name), role(role)
    {
    }

public:
    QString id;
    QString name;
    ROLE role;
};

class Config
{
public:
    Config() : host_ip("localhost"),
               host_port(0)
    {
    }

    void load();

public:
    QString app_name;         //应用名称
    QString host_ip;          //服务器地址
    int host_port;            //服务器端口
    QString db_name;          //数据库名称
    QString db_user_id;       //数据库账号
    QString db_user_password; //数据库密码
    QString ui_style;         //界面风格
};

class Runtime
{
public:
    Runtime();
    virtual ~Runtime();

public:
    void init();
    void setContext(const QString &id, const QString &name, ROLE role);
    Context *getContext();
    Config &getConfig();
    bool startDBManager();
    DBManager &getDBManager();

private:
    Context *context_;
    Config config;
    DBManager dbmanager;
};

extern Runtime runtime;

#endif // RUNTIME_H
