#ifndef VACATEDIALOG_H
#define VACATEDIALOG_H

#include "runtime.h"
#include <QDialog>

namespace Ui
{
    class VacateDialog;
}

enum class VACATE_DIALOG
{
    CREATE,
    MODIFY,
    READONLY
};

class VacateDialog : public QDialog
{
    Q_OBJECT

public:
    explicit VacateDialog(const QString &id, const QString &user_id, VACATE_DIALOG mode, QWidget *parent = nullptr);
    ~VacateDialog();

private slots:
    void on_pushButton_clicked();

private:
    //下载数据
    void download();
    //上传数据
    void upload();
    //检测数据
    bool check();

private:
    Ui::VacateDialog *ui;
    QString id;
    QString user_id;
    VACATE_DIALOG mode;
};

#endif // VACATEDIALOG_H
