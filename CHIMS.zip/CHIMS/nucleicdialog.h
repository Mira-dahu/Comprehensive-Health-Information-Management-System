#ifndef NUCLEICDIALOG_H
#define NUCLEICDIALOG_H

#include "runtime.h"
#include <QDialog>

namespace Ui
{
    class NucleicDialog;
}

enum class NUCLEIC_DIALOG
{
    CREATE,
    MODIFY,
    READONLY
};

class NucleicDialog : public QDialog
{
    Q_OBJECT

public:
    explicit NucleicDialog(const QString &id, const QString &user_id, NUCLEIC_DIALOG mode, QWidget *parent = nullptr);
    ~NucleicDialog();

private slots:
    void on_pushButton_clicked();
    void on_pushButtonImage_clicked();

private:
    //下载数据
    void download();
    //上传数据
    void upload();
    //检测数据
    bool check();

private:
    Ui::NucleicDialog *ui;
    QString imagefile;
    QString id;
    QString user_id;
    NUCLEIC_DIALOG mode;
};

#endif // NUCLEICDIALOG_H
