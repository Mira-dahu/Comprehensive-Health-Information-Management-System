#ifndef ADMINWINDOW_H
#define ADMINWINDOW_H

#include "runtime.h"
#include <QMainWindow>
#include <QtSql/QSqlQueryModel>

QT_BEGIN_NAMESPACE
namespace Ui
{
    class AdminWindow;
}
QT_END_NAMESPACE

class AdminWindow : public QMainWindow
{
    Q_OBJECT

public:
    AdminWindow(QWidget *parent = nullptr);
    ~AdminWindow();

private slots:
    void on_actionQuit_triggered();
    void on_actionAccount_triggered();
    void on_tabWidget_currentChanged(int index);
    void on_tableViewUser_doubleClicked(const QModelIndex &index);
    void on_pushButtonUserAdd_clicked();
    void on_pushButtonUserRemove_clicked();
    void on_pushButtonUserSearch_clicked();
    void on_pushButtonUserRefresh_clicked();
    void on_tableViewVaccination_doubleClicked(const QModelIndex &index);
    void on_pushButtonVaccinationAdd_clicked();
    void on_pushButtonVaccinationRemove_clicked();
    void on_pushButtonVaccinationSearch_clicked();
    void on_pushButtonVaccinationRefresh_clicked();
    void on_tableViewNucleic_doubleClicked(const QModelIndex &index);
    void on_pushButtonNucleicAdd_clicked();
    void on_pushButtonNucleicRemove_clicked();
    void on_pushButtonNucleicSearch_clicked();
    void on_pushButtonNucleicRefresh_clicked();
    void on_tableViewHealth_doubleClicked(const QModelIndex &index);
    void on_pushButtonHealthAdd_clicked();
    void on_pushButtonHealthRemove_clicked();
    void on_pushButtonHealthSearch_clicked();
    void on_pushButtonHealthRefresh_clicked();
    void on_tableViewRoute_doubleClicked(const QModelIndex &index);
    void on_pushButtonRouteAdd_clicked();
    void on_pushButtonRouteRemove_clicked();
    void on_pushButtonRouteSearch_clicked();
    void on_pushButtonRouteRefresh_clicked();
    void on_tableViewVacate_doubleClicked(const QModelIndex &index);
    void on_pushButtonVacateRemove_clicked();
    void on_pushButtonVacateSearch_clicked();
    void on_pushButtonVacateRefresh_clicked();

private:
    void initTableView();
    void initStatusBar();

private:
    void refreshTableViewUser();
    void refreshTableViewVaccination();
    void refreshTableViewNucleic();
    void refreshTableViewHealth();
    void refreshTableViewRoute();
    void refreshTableViewVacate();

private:
    Ui::AdminWindow *ui;
    QSqlQueryModel *modeluser;        //用户信息
    QSqlQueryModel *modelvaccination; //疫苗接种
    QSqlQueryModel *modelnucleic;     //核酸检测
    QSqlQueryModel *modelhealth;      //健康打卡
    QSqlQueryModel *modelroute;       //行程上报
    QSqlQueryModel *modelvacate;      //请假审批
};
#endif // ADMINWINDOW_H
