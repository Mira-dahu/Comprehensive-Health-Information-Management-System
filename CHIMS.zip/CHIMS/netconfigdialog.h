#ifndef NETCONFIGDIALOG_H
#define NETCONFIGDIALOG_H

#include "runtime.h"
#include <QDialog>

namespace Ui
{
    class NetConfigDialog;
}

class NetConfigDialog : public QDialog
{
    Q_OBJECT

public:
    explicit NetConfigDialog(QWidget *parent = nullptr);
    ~NetConfigDialog();

private slots:
    void on_pushButton_clicked();

private:
    Ui::NetConfigDialog *ui;
};

#endif // NETCONFIGDIALOG_H
