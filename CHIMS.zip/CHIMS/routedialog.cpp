#include "routedialog.h"
#include "ui_routedialog.h"
#include <QMessageBox>
#include <QDate>
#include <QSqlError>
#include <QDebug>

RouteDialog::RouteDialog(const QString &id, const QString &user_id, ROUTE_DIALOG mode, QWidget *parent) : QDialog(parent),
                                                                                                          ui(new Ui::RouteDialog),
                                                                                                          id(id),
                                                                                                          user_id(user_id),
                                                                                                          mode(mode)
{
    ui->setupUi(this);
    setWindowTitle("行程上报信息");
    ui->dateTimeEdit->setCalendarPopup(true);
    ui->dateTimeEdit->setDateTime(QDateTime::currentDateTime());
    ui->pushButton->setDefault(true);
    ui->lineEditID->setReadOnly(true);
    ui->lineEditUserName->setReadOnly(true);

    switch (mode)
    {
    case ROUTE_DIALOG::CREATE:
        ui->labelID->setVisible(false);
        ui->lineEditID->setVisible(false);
        ui->pushButton->setText("提交");
        break;
    case ROUTE_DIALOG::MODIFY:
        ui->pushButton->setText("更新");
        ui->lineEditID->setReadOnly(true);
        ui->lineEditUserID->setReadOnly(true);
        break;
    case ROUTE_DIALOG::READONLY:
        ui->pushButton->setVisible(false);
        ui->lineEditID->setReadOnly(true);
        ui->lineEditUserID->setReadOnly(true);
        ui->lineEditPlace->setReadOnly(false);
        ui->dateTimeEdit->setEnabled(false);
        break;
    }
    download();
}

RouteDialog::~RouteDialog()
{
    delete ui;
}

void RouteDialog::on_pushButton_clicked()
{
    if (check())
    {
        upload();
    }
}

void RouteDialog::download()
{
    if (!user_id.isEmpty())
    {
        ui->lineEditUserID->setReadOnly(true);
        ui->lineEditUserID->setText(user_id);
        QString sql = QString("SELECT name FROM user WHERE id = '%1'")
                          .arg(user_id);
        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            if (query.next())
            {
                ui->lineEditUserName->setText(query.value(0).toString());
            }
            else
            {
                QMessageBox::warning(this, "提示", "未找到客户信息！");
            }
        }
        else
        {
            QMessageBox::warning(this, "提示", query.lastError().text());
        }
    }

    if (!id.isEmpty())
    {
        QString sql = QString("SELECT * FROM route WHERE route.id = '%1'")
                          .arg(id);
        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            if (query.next())
            {
                ui->lineEditID->setText(query.value(0).toString());
                ui->lineEditUserID->setText(query.value(1).toString());
                ui->lineEditPlace->setText(query.value(2).toString());
                ui->dateTimeEdit->setDateTime(query.value(3).toDateTime());
            }
            else
            {
                QMessageBox::warning(this, "提示", "未找到信息！");
            }
        }
        else
        {
            QMessageBox::warning(this, "提示", query.lastError().text());
        }
    }
}

void RouteDialog::upload()
{
    QString place = ui->lineEditPlace->text().trimmed();
    QString time = ui->dateTimeEdit->dateTime().toString("yyyy-MM-dd hh:mm:ss");

    if (place.isEmpty())
    {
        QMessageBox::warning(this, "错误提示", "请填写去往地区！");
        return;
    }

    if (mode == ROUTE_DIALOG::CREATE)
    {
        user_id = ui->lineEditUserID->text().trimmed();
        QString sql = QString(
                          "INSERT INTO route(id, user_id, place, time)"
                          "VALUES(UUID(), '%1', '%2', '%3')")
                          .arg(user_id)
                          .arg(place)
                          .arg(time);

        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            QMessageBox::information(this, "提示", "提交成功");
            accept();
        }
        else
        {
            qDebug() << query.lastError().text();
            QMessageBox::warning(this, "提示", "提交失败");
        }
    }
    else
    {
        id = ui->lineEditID->text().trimmed();
        QString sql = QString(
                          "UPDATE route SET "
                          "place = '%2', "
                          "time = '%3' "
                          "WHERE id = '%1'")
                          .arg(id)
                          .arg(place)
                          .arg(time);

        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            QMessageBox::information(this, "提示", "更新成功");
            accept();
        }
        else
        {
            qDebug() << query.lastError().text();
            QMessageBox::warning(this, "提示", "更新失败");
        }
    }
}

bool RouteDialog::check()
{
    user_id = ui->lineEditUserID->text().trimmed();
    if (!user_id.isEmpty())
    {
        QString sql = QString("SELECT count(*) FROM user WHERE id = '%1'")
                          .arg(user_id);
        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            if (query.next() && query.value(0).toInt() == 0)
            {
                QMessageBox::warning(this, "提示", "未找到客户信息！");
                return false;
            }
        }
        else
        {
            QMessageBox::warning(this, "提示", query.lastError().text());
        }
    }
    return true;
}
