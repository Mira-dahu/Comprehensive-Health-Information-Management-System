#include "userwindow.h"
#include "ui_userwindow.h"
#include "userdialog.h"
#include "searchdialog.h"
#include "vaccinationdialog.h"
#include "nucleicdialog.h"
#include "healthdialog.h"
#include "routedialog.h"
#include "vacatedialog.h"
#include "washdialog.h"
#include <QTimer>
#include <QSqlQueryModel>
#include <QSqlRecord>
#include <QSqlError>
#include <QMessageBox>
#include <QLabel>
#include <QDebug>

UserWindow::UserWindow(QWidget *parent) : QMainWindow(parent),
                                          ui(new Ui::UserWindow)
{
    ui->setupUi(this);
    setWindowTitle(runtime.getConfig().app_name);
    initTableView();
    initStatusBar();
    refreshTableViewVaccination();
}

UserWindow::~UserWindow()
{
    delete ui;
}

void UserWindow::on_actionAccount_triggered()
{
    UserDialog dlg(runtime.getContext()->id, USER_DIALOG::MODIFY, this);
    dlg.exec();
}

void UserWindow::on_actionQuit_triggered()
{
    close();
}

void UserWindow::initTableView()
{
    //设定选定整合模式
    ui->tableViewVaccination->setSelectionBehavior(QAbstractItemView::SelectRows);
    //设定只能选取单行模式
    ui->tableViewVaccination->setSelectionMode(QAbstractItemView::SingleSelection);
    //禁止单元格编辑
    ui->tableViewVaccination->setEditTriggers(QAbstractItemView::NoEditTriggers);
    //设置颜色交替
    ui->tableViewVaccination->setAlternatingRowColors(true);
    modelvaccination = new QSqlQueryModel(this);
    ui->tableViewVaccination->setModel(modelvaccination);

    //设定选定整合模式
    ui->tableViewNucleic->setSelectionBehavior(QAbstractItemView::SelectRows);
    //设定只能选取单行模式
    ui->tableViewNucleic->setSelectionMode(QAbstractItemView::SingleSelection);
    //禁止单元格编辑
    ui->tableViewNucleic->setEditTriggers(QAbstractItemView::NoEditTriggers);
    //设置颜色交替
    ui->tableViewNucleic->setAlternatingRowColors(true);
    modelnucleic = new QSqlQueryModel(this);
    ui->tableViewNucleic->setModel(modelnucleic);

    //设定选定整合模式
    ui->tableViewHealth->setSelectionBehavior(QAbstractItemView::SelectRows);
    //设定只能选取单行模式
    ui->tableViewHealth->setSelectionMode(QAbstractItemView::SingleSelection);
    //禁止单元格编辑
    ui->tableViewHealth->setEditTriggers(QAbstractItemView::NoEditTriggers);
    //设置颜色交替
    ui->tableViewHealth->setAlternatingRowColors(true);
    modelhealth = new QSqlQueryModel(this);
    ui->tableViewHealth->setModel(modelhealth);

    //设定选定整合模式
    ui->tableViewRoute->setSelectionBehavior(QAbstractItemView::SelectRows);
    //设定只能选取单行模式
    ui->tableViewRoute->setSelectionMode(QAbstractItemView::SingleSelection);
    //禁止单元格编辑
    ui->tableViewRoute->setEditTriggers(QAbstractItemView::NoEditTriggers);
    //设置颜色交替
    ui->tableViewRoute->setAlternatingRowColors(true);
    modelroute = new QSqlQueryModel(this);
    ui->tableViewRoute->setModel(modelroute);

    //设定选定整合模式
    ui->tableViewArea->setSelectionBehavior(QAbstractItemView::SelectRows);
    //设定只能选取单行模式
    ui->tableViewArea->setSelectionMode(QAbstractItemView::SingleSelection);
    //禁止单元格编辑
    ui->tableViewArea->setEditTriggers(QAbstractItemView::NoEditTriggers);
    //设置颜色交替
    ui->tableViewArea->setAlternatingRowColors(true);
    modelarea = new QSqlQueryModel(this);
    ui->tableViewArea->setModel(modelarea);

    //设置最后一栏自适应长度
    // ui->tableViewVacate->horizontalHeader()->setStretchLastSection(true);
    //设定选定整合模式
    ui->tableViewVacate->setSelectionBehavior(QAbstractItemView::SelectRows);
    //设定只能选取单行模式
    ui->tableViewVacate->setSelectionMode(QAbstractItemView::SingleSelection);
    //禁止单元格编辑
    ui->tableViewVacate->setEditTriggers(QAbstractItemView::NoEditTriggers);
    //设置颜色交替
    ui->tableViewVacate->setAlternatingRowColors(true);
    modelvacate = new QSqlQueryModel(this);
    ui->tableViewVacate->setModel(modelvacate);

    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, [=]()
            {
            timer->stop();
            WashDialog dlg(this);
            dlg.exec(); });

    timer->start(100);
}

void UserWindow::initStatusBar()
{
    QLabel *info = new QLabel(this);
    info->setText(QString("用户 | %1").arg(runtime.getContext()->id));
    statusBar()->insertPermanentWidget(0, info);
}

void UserWindow::refreshTableViewVaccination()
{
    QString sql = QString(
                      "SELECT "
                      "vaccination.id as '流水号', "
                      "user.id as '账号', "
                      "user.name as '姓名', "
                      "vaccination.place as '接种地点', "
                      "vaccination.version as '疫苗型号', "
                      "vaccination.time as '接种时间' "
                      "FROM user, vaccination "
                      "WHERE user.id = vaccination.user_id AND user.id = '%1'")
                      .arg(runtime.getContext()->id);
    modelvaccination->setQuery(sql, runtime.getDBManager().getDB());
}

void UserWindow::refreshTableViewNucleic()
{
    QString sql = QString(
                      "SELECT "
                      "nucleic.id as '流水号', "
                      "user.id as '账号', "
                      "user.name as '姓名', "
                      "nucleic.place as '测试地点', "
                      "nucleic.result as '测试结果', "
                      "nucleic.time as '测试时间' "
                      "FROM user, nucleic "
                      "WHERE user.id = nucleic.user_id AND user.id = '%1'")
                      .arg(runtime.getContext()->id);
    modelnucleic->setQuery(sql, runtime.getDBManager().getDB());
}

void UserWindow::refreshTableViewHealth()
{
    QString sql = QString(
                      "SELECT "
                      "health.id as '流水号', "
                      "user.id as '账号', "
                      "user.name as '姓名', "
                      "health.place as '地点', "
                      "health.isolate as '是否隔离', "
                      "health.heat1 as '体温（上午）', "
                      "health.heat2 as '体温（下午）', "
                      "health.heat3 as '体温（晚上）', "
                      "health.cough as '咳嗽', "
                      "health.fever as '发烧', "
                      "health.date as '日期' "
                      "FROM user, health "
                      "WHERE user.id = health.user_id AND user.id = '%1'")
                      .arg(runtime.getContext()->id);
    modelhealth->setQuery(sql, runtime.getDBManager().getDB());
}

void UserWindow::refreshTableViewRoute()
{
    QString sql = QString(
                      "SELECT "
                      "route.id as '流水号', "
                      "user.id as '账号', "
                      "user.name as '姓名', "
                      "route.place as '去往地区', "
                      "route.time as '时间' "
                      "FROM user, route "
                      "WHERE user.id = route.user_id AND user.id = '%1'")
                      .arg(runtime.getContext()->id);
    modelroute->setQuery(sql, runtime.getDBManager().getDB());
}

void UserWindow::refreshTableViewArea()
{
    QString sql = QString(
        "SELECT "
        "name as '区域', "
        "risk as '风险等级' "
        "FROM area");

    modelarea->setQuery(sql, runtime.getDBManager().getDB());
}

void UserWindow::refreshTableViewVacate()
{
    QString sql = QString(
                      "SELECT "
                      "vacate.id as '流水号', "
                      "user.id as '账号', "
                      "user.name as '姓名', "
                      "vacate.reason as '请假理由', "
                      "vacate.days as '请假天数', "
                      "vacate.state as '审批状态', "
                      "vacate.time as '请假时间' "
                      "FROM user, vacate "
                      "WHERE user.id = vacate.user_id AND user.id = '%1' "
                      "ORDER BY vacate.time DESC")
                      .arg(runtime.getContext()->id);
    qDebug() << sql;
    modelvacate->setQuery(sql, runtime.getDBManager().getDB());
}

void UserWindow::on_tabWidget_currentChanged(int index)
{
    switch (index)
    {
    case 0:
        refreshTableViewVaccination();
        break;
    case 1:
        refreshTableViewNucleic();
        break;
    case 2:
        refreshTableViewHealth();
        break;
    case 3:
        refreshTableViewRoute();
        break;
    case 4:
        refreshTableViewArea();
        break;
    case 5:
        refreshTableViewVacate();
        break;
    }
}

void UserWindow::on_tableViewVaccination_doubleClicked(const QModelIndex &index)
{
    QSqlRecord record = modelvaccination->record(index.row());
    QString id = record.value(0).toString();
    QString user_id = record.value(1).toString();
    VaccinationDialog dlg(id, user_id, VACCINATION_DIALOG::READONLY, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewVaccination();
    }
}

void UserWindow::on_pushButtonVaccinationAdd_clicked()
{
    VaccinationDialog dlg("", runtime.getContext()->id, VACCINATION_DIALOG::CREATE, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewVaccination();
    }
}

void UserWindow::on_pushButtonVaccinationRefresh_clicked()
{
    refreshTableViewVaccination();
}

void UserWindow::on_tableViewNucleic_doubleClicked(const QModelIndex &index)
{
    QSqlRecord record = modelnucleic->record(index.row());
    QString id = record.value(0).toString();
    QString user_id = record.value(1).toString();
    NucleicDialog dlg(id, user_id, NUCLEIC_DIALOG::READONLY, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewNucleic();
    }
}

void UserWindow::on_pushButtonNucleicAdd_clicked()
{
    NucleicDialog dlg("", runtime.getContext()->id, NUCLEIC_DIALOG::CREATE, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewNucleic();
    }
}

void UserWindow::on_pushButtonNucleicRefresh_clicked()
{
    refreshTableViewNucleic();
}

void UserWindow::on_tableViewHealth_doubleClicked(const QModelIndex &index)
{
    QSqlRecord record = modelhealth->record(index.row());
    QString id = record.value(0).toString();
    QString user_id = record.value(1).toString();
    HealthDialog dlg(id, user_id, HEALTH_DIALOG::READONLY, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewHealth();
    }
}

void UserWindow::on_pushButtonHealthAdd_clicked()
{
    HealthDialog dlg("", runtime.getContext()->id, HEALTH_DIALOG::CREATE, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewHealth();
    }
}

void UserWindow::on_pushButtonHealthRefresh_clicked()
{
    refreshTableViewHealth();
}

void UserWindow::on_tableViewRoute_doubleClicked(const QModelIndex &index)
{
    QSqlRecord record = modelroute->record(index.row());
    QString id = record.value(0).toString();
    QString user_id = record.value(1).toString();
    RouteDialog dlg(id, user_id, ROUTE_DIALOG::READONLY, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewRoute();
    }
}

void UserWindow::on_pushButtonRouteAdd_clicked()
{
    RouteDialog dlg("", runtime.getContext()->id, ROUTE_DIALOG::CREATE, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewRoute();
    }
}

void UserWindow::on_pushButtonRouteRefresh_clicked()
{
    refreshTableViewRoute();
}

void UserWindow::on_pushButtonAreaRefresh_clicked()
{
    refreshTableViewArea();
}

void UserWindow::on_tableViewVacate_doubleClicked(const QModelIndex &index)
{
    QSqlRecord record = modelvacate->record(index.row());
    QString id = record.value(0).toString();
    QString user_id = record.value(1).toString();
    VacateDialog dlg(id, user_id, VACATE_DIALOG::READONLY, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewVacate();
    }
}

void UserWindow::on_pushButtonVacateAdd_clicked()
{
    VacateDialog dlg("", runtime.getContext()->id, VACATE_DIALOG::CREATE, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewVacate();
    }
}

void UserWindow::on_pushButtonVacateRefresh_clicked()
{
    refreshTableViewVacate();
}
