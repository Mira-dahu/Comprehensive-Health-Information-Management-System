#ifndef USERWINDOW_H
#define USERWINDOW_H

#include "runtime.h"
#include <QMainWindow>
#include <QSqlQueryModel>

namespace Ui
{
    class UserWindow;
}

class UserWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit UserWindow(QWidget *parent = nullptr);
    ~UserWindow();

private slots:
    void on_actionAccount_triggered();
    void on_actionQuit_triggered();
    void on_tabWidget_currentChanged(int index);
    void on_tableViewVaccination_doubleClicked(const QModelIndex &index);
    void on_pushButtonVaccinationAdd_clicked();
    void on_pushButtonVaccinationRefresh_clicked();
    void on_tableViewNucleic_doubleClicked(const QModelIndex &index);
    void on_pushButtonNucleicAdd_clicked();
    void on_pushButtonNucleicRefresh_clicked();
    void on_tableViewHealth_doubleClicked(const QModelIndex &index);
    void on_pushButtonHealthAdd_clicked();
    void on_pushButtonHealthRefresh_clicked();
    void on_tableViewRoute_doubleClicked(const QModelIndex &index);
    void on_pushButtonRouteAdd_clicked();
    void on_pushButtonRouteRefresh_clicked();
    void on_pushButtonAreaRefresh_clicked();
    void on_tableViewVacate_doubleClicked(const QModelIndex &index);
    void on_pushButtonVacateAdd_clicked();
    void on_pushButtonVacateRefresh_clicked();

private:
    void initTableView();
    void initStatusBar();

private:
    void refreshTableViewVaccination();
    void refreshTableViewNucleic();
    void refreshTableViewHealth();
    void refreshTableViewRoute();
    void refreshTableViewArea();
    void refreshTableViewVacate();

private:
    Ui::UserWindow *ui;
    QSqlQueryModel *modelvaccination; //疫苗接种
    QSqlQueryModel *modelnucleic;     //核酸检测
    QSqlQueryModel *modelhealth;      //健康打卡
    QSqlQueryModel *modelroute;       //行程上报
    QSqlQueryModel *modelarea;        //风险区域
    QSqlQueryModel *modelvacate;      //请假申请
};

#endif // USERWINDOW_H
