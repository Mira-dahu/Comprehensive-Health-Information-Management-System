#include "runtime.h"
#include "qss/rc.qrc"
#include <QSettings>
#include <QTextCodec>
#include <QCoreApplication>
#include <QFile>
#include <QDebug>

void Config::load()
{
    QString filename = QCoreApplication::applicationDirPath() + "/config.ini";
    // if(!QFile::exists(filename)) {
    QFile input("://config.ini");
    if (input.open(QFile::ReadOnly))
    {
        QFile output(filename);
        if (output.open(QIODevice::WriteOnly))
        {
            output.write(input.readAll());
            output.close();
        }
    }
    //}

    QSettings settings(filename, QSettings::IniFormat);
    settings.setIniCodec(QTextCodec::codecForName("utf-8"));
    app_name = settings.value("AppConfig/AppName").toString();
    host_ip = settings.value("NetConfig/HostIP").toString();
    host_port = settings.value("NetConfig/HostPort").toInt();
    db_name = settings.value("NetConfig/DatabaseName").toString();
    db_user_id = settings.value("NetConfig/DatabaseUserID").toString();
    db_user_password = settings.value("NetConfig/DatabaseUserPassword").toString();
    ui_style = settings.value("UIConfig/Style").toString();
}

Runtime::Runtime()
    : context_(nullptr)
{
}

Runtime::~Runtime()
{
    if (context_)
    {
        delete context_;
        context_ = nullptr;
    }
}

void Runtime::init()
{
    config.load();
}

void Runtime::setContext(const QString &id, const QString &name, ROLE role)
{
    if (!context_)
    {
        context_ = new Context(id, name, role);
    }
    else
    {
        context_->id = id;
        context_->name = name;
        context_->role = role;
    }
}

Context *Runtime::getContext()
{
    return context_;
}

Config &Runtime::getConfig()
{
    return config;
}

bool Runtime::startDBManager()
{
    dbmanager.check();
    return dbmanager.start(config.host_ip, config.host_port, config.db_name, config.db_user_id, config.db_user_password);
}

DBManager &Runtime::getDBManager()
{
    return dbmanager;
}

Runtime runtime;
