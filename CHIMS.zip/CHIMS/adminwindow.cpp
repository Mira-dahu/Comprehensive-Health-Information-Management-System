#include "adminwindow.h"
#include "ui_adminwindow.h"
#include "admindialog.h"
#include "userdialog.h"
#include "searchdialog.h"
#include "vaccinationdialog.h"
#include "nucleicdialog.h"
#include "healthdialog.h"
#include "routedialog.h"
#include "vacatedialog.h"
#include <QSqlRecord>
#include <QSqlError>
#include <QMessageBox>
#include <QLabel>
#include <QDebug>

AdminWindow::AdminWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::AdminWindow), modeluser(nullptr), modelvaccination(nullptr), modelnucleic(nullptr), modelhealth(nullptr), modelroute(nullptr)
{
    ui->setupUi(this);
    setWindowTitle(runtime.getConfig().app_name);
    initStatusBar();
    initTableView();
    refreshTableViewUser();
}

AdminWindow::~AdminWindow()
{
    delete ui;
}

void AdminWindow::initTableView()
{
    //设置最后一栏自适应长度
    // ui->tableViewUser->horizontalHeader()->setStretchLastSection(true);
    //设定选定整合模式
    ui->tableViewUser->setSelectionBehavior(QAbstractItemView::SelectRows);
    //设定只能选取单行模式
    ui->tableViewUser->setSelectionMode(QAbstractItemView::SingleSelection);
    //禁止单元格编辑
    ui->tableViewUser->setEditTriggers(QAbstractItemView::NoEditTriggers);
    //设置颜色交替
    ui->tableViewUser->setAlternatingRowColors(true);
    modeluser = new QSqlQueryModel(this);
    ui->tableViewUser->setModel(modeluser);

    //设置最后一栏自适应长度
    // ui->tableViewVaccination->horizontalHeader()->setStretchLastSection(true);
    //设定选定整合模式
    ui->tableViewVaccination->setSelectionBehavior(QAbstractItemView::SelectRows);
    //设定只能选取单行模式
    ui->tableViewVaccination->setSelectionMode(QAbstractItemView::SingleSelection);
    //禁止单元格编辑
    ui->tableViewVaccination->setEditTriggers(QAbstractItemView::NoEditTriggers);
    //设置颜色交替
    ui->tableViewVaccination->setAlternatingRowColors(true);
    modelvaccination = new QSqlQueryModel(this);
    ui->tableViewVaccination->setModel(modelvaccination);

    //设置最后一栏自适应长度
    // ui->tableViewNucleic->horizontalHeader()->setStretchLastSection(true);
    //设定选定整合模式
    ui->tableViewNucleic->setSelectionBehavior(QAbstractItemView::SelectRows);
    //设定只能选取单行模式
    ui->tableViewNucleic->setSelectionMode(QAbstractItemView::SingleSelection);
    //禁止单元格编辑
    ui->tableViewNucleic->setEditTriggers(QAbstractItemView::NoEditTriggers);
    //设置颜色交替
    ui->tableViewNucleic->setAlternatingRowColors(true);
    modelnucleic = new QSqlQueryModel(this);
    ui->tableViewNucleic->setModel(modelnucleic);

    //设置最后一栏自适应长度
    // ui->tableViewHealth->horizontalHeader()->setStretchLastSection(true);
    //设定选定整合模式
    ui->tableViewHealth->setSelectionBehavior(QAbstractItemView::SelectRows);
    //设定只能选取单行模式
    ui->tableViewHealth->setSelectionMode(QAbstractItemView::SingleSelection);
    //禁止单元格编辑
    ui->tableViewHealth->setEditTriggers(QAbstractItemView::NoEditTriggers);
    //设置颜色交替
    ui->tableViewHealth->setAlternatingRowColors(true);
    modelhealth = new QSqlQueryModel(this);
    ui->tableViewHealth->setModel(modelhealth);

    //设置最后一栏自适应长度
    // ui->tableViewRoute->horizontalHeader()->setStretchLastSection(true);
    //设定选定整合模式
    ui->tableViewRoute->setSelectionBehavior(QAbstractItemView::SelectRows);
    //设定只能选取单行模式
    ui->tableViewRoute->setSelectionMode(QAbstractItemView::SingleSelection);
    //禁止单元格编辑
    ui->tableViewRoute->setEditTriggers(QAbstractItemView::NoEditTriggers);
    //设置颜色交替
    ui->tableViewRoute->setAlternatingRowColors(true);
    modelroute = new QSqlQueryModel(this);
    ui->tableViewRoute->setModel(modelroute);

    //设置最后一栏自适应长度
    // ui->tableViewVacate->horizontalHeader()->setStretchLastSection(true);
    //设定选定整合模式
    ui->tableViewVacate->setSelectionBehavior(QAbstractItemView::SelectRows);
    //设定只能选取单行模式
    ui->tableViewVacate->setSelectionMode(QAbstractItemView::SingleSelection);
    //禁止单元格编辑
    ui->tableViewVacate->setEditTriggers(QAbstractItemView::NoEditTriggers);
    //设置颜色交替
    ui->tableViewVacate->setAlternatingRowColors(true);
    modelvacate = new QSqlQueryModel(this);
    ui->tableViewVacate->setModel(modelvacate);
}

void AdminWindow::initStatusBar()
{
    QLabel *info = new QLabel(this);
    info->setText(QString("管理员 | %1").arg(runtime.getContext()->id));
    statusBar()->insertPermanentWidget(0, info);
}

void AdminWindow::refreshTableViewUser()
{
    QString sql = QString(
        "SELECT "
        "id as '账号', "
        "password as '密码', "
        "name as '姓名', "
        "sex as '性别', "
        "birthday as '生日', "
        "tel as '电话', "
        "classes as '班级', "
        "subject as '专业', "
        "college as '学院' "
        "FROM user");
    modeluser->setQuery(sql, runtime.getDBManager().getDB());
}

void AdminWindow::refreshTableViewVaccination()
{
    QString sql = QString(
        "SELECT "
        "vaccination.id as '流水号', "
        "user.id as '账号', "
        "user.name as '姓名', "
        "vaccination.place as '接种地点', "
        "vaccination.version as '疫苗型号', "
        "vaccination.time as '接种时间' "
        "FROM user, vaccination "
        "WHERE user.id = vaccination.user_id");
    modelvaccination->setQuery(sql, runtime.getDBManager().getDB());
}

void AdminWindow::refreshTableViewNucleic()
{
    QString sql = QString(
        "SELECT "
        "nucleic.id as '流水号', "
        "user.id as '账号', "
        "user.name as '姓名', "
        "nucleic.place as '测试地点', "
        "nucleic.result as '测试结果', "
        "nucleic.time as '测试时间' "
        "FROM user, nucleic "
        "WHERE user.id = nucleic.user_id");
    modelnucleic->setQuery(sql, runtime.getDBManager().getDB());
}

void AdminWindow::refreshTableViewHealth()
{
    QString sql = QString(
        "SELECT "
        "health.id as '流水号', "
        "user.id as '账号', "
        "user.name as '姓名', "
        "health.place as '地点', "
        "health.isolate as '是否隔离', "
        "health.heat1 as '体温（上午）', "
        "health.heat2 as '体温（下午）', "
        "health.heat3 as '体温（晚上）', "
        "health.cough as '咳嗽', "
        "health.fever as '发烧', "
        "health.date as '日期' "
        "FROM user, health "
        "WHERE user.id = health.user_id");
    modelhealth->setQuery(sql, runtime.getDBManager().getDB());
}

void AdminWindow::refreshTableViewRoute()
{
    QString sql = QString(
        "SELECT "
        "route.id as '流水号', "
        "user.id as '账号', "
        "user.name as '姓名', "
        "route.place as '去往地区', "
        "route.time as '时间' "
        "FROM user, route "
        "WHERE user.id = route.user_id");
    modelroute->setQuery(sql, runtime.getDBManager().getDB());
}

void AdminWindow::refreshTableViewVacate()
{
    QString sql = QString(
        "SELECT "
        "vacate.id as '流水号', "
        "user.id as '账号', "
        "user.name as '姓名', "
        "vacate.reason as '请假理由', "
        "vacate.days as '请假天数', "
        "vacate.state as '审批状态', "
        "vacate.time as '请假时间' "
        "FROM user, vacate "
        "WHERE user.id = vacate.user_id "
        "ORDER BY vacate.time DESC");
    qDebug() << sql;
    modelvacate->setQuery(sql, runtime.getDBManager().getDB());
}

void AdminWindow::on_actionAccount_triggered()
{
    AdminDialog dlg(runtime.getContext()->id, this);
    dlg.exec();
}

void AdminWindow::on_actionQuit_triggered()
{
    close();
}

void AdminWindow::on_tabWidget_currentChanged(int index)
{
    switch (index)
    {
    case 0:
        refreshTableViewUser();
        break;
    case 1:
        refreshTableViewVaccination();
        break;
    case 2:
        refreshTableViewNucleic();
        break;
    case 3:
        refreshTableViewHealth();
        break;
    case 4:
        refreshTableViewRoute();
        break;
    case 5:
        refreshTableViewVacate();
        break;
    }
}

void AdminWindow::on_tableViewUser_doubleClicked(const QModelIndex &index)
{
    QSqlRecord record = modeluser->record(index.row());
    QString id = record.value(0).toString();
    UserDialog dlg(id, USER_DIALOG::MODIFY, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewUser();
    }
}

void AdminWindow::on_pushButtonUserAdd_clicked()
{
    UserDialog dlg("", USER_DIALOG::CREATE, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewUser();
    }
}

void AdminWindow::on_pushButtonUserRemove_clicked()
{
    int row = ui->tableViewUser->currentIndex().row();
    if (row >= 0)
    {
        QAbstractItemModel *model = ui->tableViewUser->model();
        QModelIndex index = model->index(row, 0);
        QString id = model->data(index).toString();

        QString sql = QString("DELETE FROM user WHERE id = '%1'")
                          .arg(id);

        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            refreshTableViewUser();
            QMessageBox::information(this, "提示", "删除成功");
        }
        else
        {
            qDebug() << query.lastError().text();
            QMessageBox::warning(this, "提示", "删除失败");
        }
    }
    else
    {
        QMessageBox::warning(this, "提示", "请选中要删除的信息");
    }
}

void AdminWindow::on_pushButtonUserSearch_clicked()
{
    SearchDialog dlg(this);
    dlg.addOption("账号", "id");
    dlg.addOption("姓名", "name");
    dlg.addOption("性别", "sex");
    dlg.addOption("生日", "birthday");
    dlg.addOption("电话", "tel");
    dlg.make();
    if (dlg.exec() == QDialog::Accepted)
    {
        QString filter;
        if (dlg.getName() == "birthday")
        {
            filter = dlg.formatTime();
        }
        else
        {
            filter = dlg.formatLike();
        }

        QString sql = QString(
                          "SELECT "
                          "id as '账号', "
                          "password as '密码', "
                          "name as '姓名', "
                          "sex as '性别', "
                          "birthday as '生日', "
                          "tel as '电话', "
                          "classes as '班级', "
                          "subject as '专业', "
                          "college as '学院' "
                          "FROM user "
                          "WHERE %1")
                          .arg(filter);

        modeluser->setQuery(sql, runtime.getDBManager().getDB());
    }
}

void AdminWindow::on_pushButtonUserRefresh_clicked()
{
    refreshTableViewUser();
}

void AdminWindow::on_tableViewVaccination_doubleClicked(const QModelIndex &index)
{
    QSqlRecord record = modelvaccination->record(index.row());
    QString id = record.value(0).toString();
    QString user_id = record.value(1).toString();
    VaccinationDialog dlg(id, user_id, VACCINATION_DIALOG::MODIFY, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewVaccination();
    }
}

void AdminWindow::on_pushButtonVaccinationAdd_clicked()
{
    VaccinationDialog dlg("", "", VACCINATION_DIALOG::CREATE, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewVaccination();
    }
}

void AdminWindow::on_pushButtonVaccinationRemove_clicked()
{
    int row = ui->tableViewVaccination->currentIndex().row();
    if (row >= 0)
    {
        QAbstractItemModel *model = ui->tableViewVaccination->model();
        QModelIndex index = model->index(row, 0);
        QString id = model->data(index).toString();

        QString sql = QString("DELETE FROM vaccination WHERE id = '%1'")
                          .arg(id);

        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            refreshTableViewVaccination();
            QMessageBox::information(this, "提示", "删除成功");
        }
        else
        {
            qDebug() << query.lastError().text();
            QMessageBox::warning(this, "提示", "删除失败");
        }
    }
    else
    {
        QMessageBox::warning(this, "提示", "请选中要删除的信息");
    }
}

void AdminWindow::on_pushButtonVaccinationSearch_clicked()
{
    SearchDialog dlg(this);
    dlg.addOption("账号", "user.id");
    dlg.addOption("姓名", "user.name");
    dlg.addOption("接种地点", "vaccination.place");
    dlg.addOption("疫苗型号", "vaccination.version");
    dlg.addOption("接种时间", "vaccination.time");
    dlg.make();
    if (dlg.exec() == QDialog::Accepted)
    {
        QString filter;
        if (dlg.getName() == "vaccination.time")
        {
            filter = dlg.formatTime();
        }
        else
        {
            filter = dlg.formatLike();
        }

        QString sql = QString(
                          "SELECT "
                          "vaccination.id as '流水号', "
                          "user.id as '账号', "
                          "user.name as '姓名', "
                          "vaccination.place as '接种地点', "
                          "vaccination.version as '疫苗型号', "
                          "vaccination.time as '接种时间' "
                          "FROM user, vaccination "
                          "WHERE user.id = vaccination.user_id AND %1")
                          .arg(filter);

        qDebug() << sql;
        modelvaccination->setQuery(sql, runtime.getDBManager().getDB());
    }
}

void AdminWindow::on_pushButtonVaccinationRefresh_clicked()
{
    refreshTableViewVaccination();
}

void AdminWindow::on_tableViewNucleic_doubleClicked(const QModelIndex &index)
{
    QSqlRecord record = modelnucleic->record(index.row());
    QString id = record.value(0).toString();
    QString user_id = record.value(1).toString();
    NucleicDialog dlg(id, user_id, NUCLEIC_DIALOG::MODIFY, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewNucleic();
    }
}

void AdminWindow::on_pushButtonNucleicAdd_clicked()
{
    NucleicDialog dlg("", "", NUCLEIC_DIALOG::CREATE, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewNucleic();
    }
}

void AdminWindow::on_pushButtonNucleicRemove_clicked()
{
    int row = ui->tableViewNucleic->currentIndex().row();
    if (row >= 0)
    {
        QAbstractItemModel *model = ui->tableViewNucleic->model();
        QModelIndex index = model->index(row, 0);
        QString id = model->data(index).toString();

        QString sql = QString("DELETE FROM nucleic WHERE id = '%1'")
                          .arg(id);

        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            refreshTableViewNucleic();
            QMessageBox::information(this, "提示", "删除成功");
        }
        else
        {
            qDebug() << query.lastError().text();
            QMessageBox::warning(this, "提示", "删除失败");
        }
    }
    else
    {
        QMessageBox::warning(this, "提示", "请选中要删除的信息");
    }
}

void AdminWindow::on_pushButtonNucleicSearch_clicked()
{
    SearchDialog dlg(this);
    dlg.addOption("账号", "user.id");
    dlg.addOption("姓名", "user.name");
    dlg.addOption("测试地点", "nucleic.place");
    dlg.addOption("测试结果", "nucleic.result");
    dlg.addOption("测试时间", "nucleic.time");
    dlg.make();
    if (dlg.exec() == QDialog::Accepted)
    {
        QString filter;
        if (dlg.getName() == "nucleic.time")
        {
            filter = dlg.formatTime();
        }
        else
        {
            filter = dlg.formatLike();
        }

        QString sql = QString(
                          "SELECT "
                          "nucleic.id as '流水号', "
                          "user.id as '账号', "
                          "user.name as '姓名', "
                          "nucleic.place as '测试地点', "
                          "nucleic.result as '测试结果', "
                          "nucleic.time as '测试时间' "
                          "FROM user, nucleic "
                          "WHERE user.id = nucleic.user_id AND %1")
                          .arg(filter);

        modelnucleic->setQuery(sql, runtime.getDBManager().getDB());
    }
}

void AdminWindow::on_pushButtonNucleicRefresh_clicked()
{
    refreshTableViewNucleic();
}

void AdminWindow::on_tableViewHealth_doubleClicked(const QModelIndex &index)
{
    QSqlRecord record = modelhealth->record(index.row());
    QString id = record.value(0).toString();
    QString user_id = record.value(1).toString();
    HealthDialog dlg(id, user_id, HEALTH_DIALOG::MODIFY, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewHealth();
    }
}

void AdminWindow::on_pushButtonHealthAdd_clicked()
{
    HealthDialog dlg("", "", HEALTH_DIALOG::CREATE, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewHealth();
    }
}

void AdminWindow::on_pushButtonHealthRemove_clicked()
{
    int row = ui->tableViewHealth->currentIndex().row();
    if (row >= 0)
    {
        QAbstractItemModel *model = ui->tableViewHealth->model();
        QModelIndex index = model->index(row, 0);
        QString id = model->data(index).toString();

        QString sql = QString("DELETE FROM health WHERE id = '%1'")
                          .arg(id);

        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            refreshTableViewNucleic();
            QMessageBox::information(this, "提示", "删除成功");
        }
        else
        {
            qDebug() << query.lastError().text();
            QMessageBox::warning(this, "提示", "删除失败");
        }
    }
    else
    {
        QMessageBox::warning(this, "提示", "请选中要删除的信息");
    }
}

void AdminWindow::on_pushButtonHealthSearch_clicked()
{
    SearchDialog dlg(this);
    dlg.addOption("账号", "user.id");
    dlg.addOption("姓名", "user.name");
    dlg.addOption("地点", "health.place");
    dlg.addOption("是否隔离", "health.isolate");
    dlg.addOption("咳嗽", "health.cough");
    dlg.addOption("发烧", "health.fever");
    dlg.addOption("体温（上午）", "health.heat1");
    dlg.addOption("体温（下午）", "health.heat2");
    dlg.addOption("体温（晚上）", "health.heat3");
    dlg.addOption("日期", "health.date");
    dlg.make();
    if (dlg.exec() == QDialog::Accepted)
    {
        QString filter;
        if (dlg.getName() == "health.date")
        {
            filter = dlg.formatTime();
        }
        else if (dlg.getName().indexOf("health.heat") != -1)
        {
            filter = dlg.formatNumber();
        }
        else
        {
            filter = dlg.formatLike();
        }

        QString sql = QString(
                          "SELECT "
                          "health.id as '流水号', "
                          "user.id as '账号', "
                          "user.name as '姓名', "
                          "health.place as '地点', "
                          "health.isolate as '是否隔离', "
                          "health.heat1 as '体温（上午）', "
                          "health.heat2 as '体温（下午）', "
                          "health.heat3 as '体温（晚上）', "
                          "health.cough as '咳嗽', "
                          "health.fever as '发烧', "
                          "health.date as '日期' "
                          "FROM user, health "
                          "WHERE user.id = health.user_id AND %1")
                          .arg(filter);

        modelhealth->setQuery(sql, runtime.getDBManager().getDB());
    }
}

void AdminWindow::on_pushButtonHealthRefresh_clicked()
{
    refreshTableViewHealth();
}

void AdminWindow::on_tableViewRoute_doubleClicked(const QModelIndex &index)
{
    QSqlRecord record = modelroute->record(index.row());
    QString id = record.value(0).toString();
    QString user_id = record.value(1).toString();
    RouteDialog dlg(id, user_id, ROUTE_DIALOG::MODIFY, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewRoute();
    }
}

void AdminWindow::on_pushButtonRouteAdd_clicked()
{
    RouteDialog dlg("", "", ROUTE_DIALOG::CREATE, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewRoute();
    }
}

void AdminWindow::on_pushButtonRouteRemove_clicked()
{
    int row = ui->tableViewRoute->currentIndex().row();
    if (row >= 0)
    {
        QAbstractItemModel *model = ui->tableViewRoute->model();
        QModelIndex index = model->index(row, 0);
        QString id = model->data(index).toString();

        QString sql = QString("DELETE FROM route WHERE id = '%1'")
                          .arg(id);

        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            refreshTableViewRoute();
            QMessageBox::information(this, "提示", "删除成功");
        }
        else
        {
            qDebug() << query.lastError().text();
            QMessageBox::warning(this, "提示", "删除失败");
        }
    }
    else
    {
        QMessageBox::warning(this, "提示", "请选中要删除的信息");
    }
}

void AdminWindow::on_pushButtonRouteSearch_clicked()
{
    SearchDialog dlg(this);
    dlg.addOption("账号", "user.id");
    dlg.addOption("姓名", "user.name");
    dlg.addOption("去往地区", "route.place");
    dlg.addOption("时间", "route.time");
    dlg.make();
    if (dlg.exec() == QDialog::Accepted)
    {
        QString filter;
        if (dlg.getName() == "route.time")
        {
            filter = dlg.formatTime();
        }
        else
        {
            filter = dlg.formatLike();
        }

        QString sql = QString(
                          "SELECT "
                          "route.id as '流水号', "
                          "user.id as '账号', "
                          "user.name as '姓名', "
                          "route.place as '去往地区', "
                          "route.time as '时间' "
                          "FROM user, route "
                          "WHERE user.id = route.user_id AND %1")
                          .arg(filter);

        modelroute->setQuery(sql, runtime.getDBManager().getDB());
    }
}

void AdminWindow::on_pushButtonRouteRefresh_clicked()
{
    refreshTableViewRoute();
}

void AdminWindow::on_tableViewVacate_doubleClicked(const QModelIndex &index)
{
    QSqlRecord record = modelvacate->record(index.row());
    QString id = record.value(0).toString();
    QString user_id = record.value(1).toString();
    VacateDialog dlg(id, user_id, VACATE_DIALOG::MODIFY, this);
    if (dlg.exec() == QDialog::Accepted)
    {
        refreshTableViewVacate();
    }
}

void AdminWindow::on_pushButtonVacateRemove_clicked()
{
    int row = ui->tableViewVacate->currentIndex().row();
    if (row >= 0)
    {
        QAbstractItemModel *model = ui->tableViewVacate->model();
        QModelIndex index = model->index(row, 0);
        QString id = model->data(index).toString();

        QString sql = QString("DELETE FROM vacate WHERE id = '%1'")
                          .arg(id);

        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            refreshTableViewVacate();
            QMessageBox::information(this, "提示", "删除成功");
        }
        else
        {
            qDebug() << query.lastError().text();
            QMessageBox::warning(this, "提示", "删除失败");
        }
    }
    else
    {
        QMessageBox::warning(this, "提示", "请选中要删除的信息");
    }
}

void AdminWindow::on_pushButtonVacateSearch_clicked()
{
    SearchDialog dlg(this);
    dlg.addOption("账号", "user.id");
    dlg.addOption("姓名", "user.name");
    dlg.addOption("审批状态", "vacate.state");
    dlg.make();
    if (dlg.exec() == QDialog::Accepted)
    {
        QString sql = QString(
                          "SELECT "
                          "vacate.id as '流水号', "
                          "user.id as '账号', "
                          "user.name as '姓名', "
                          "vacate.reason as '请假理由', "
                          "vacate.days as '请假天数', "
                          "vacate.state as '审批状态', "
                          "vacate.time as '请假时间' "
                          "FROM user, vacate "
                          "WHERE user.id = vacate.user_id AND %1 "
                          "ORDER BY vacate.time DESC")
                          .arg(dlg.formatLike());

        modelvacate->setQuery(sql, runtime.getDBManager().getDB());
    }
}

void AdminWindow::on_pushButtonVacateRefresh_clicked()
{
    refreshTableViewVacate();
}
