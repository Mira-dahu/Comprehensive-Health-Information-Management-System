#include "userdialog.h"
#include "ui_userdialog.h"
#include <QMessageBox>
#include <QDate>
#include <QSqlError>
#include <QDebug>

UserDialog::UserDialog(const QString &id, USER_DIALOG mode, QWidget *parent) : QDialog(parent),
                                                                               ui(new Ui::UserDialog),
                                                                               id(id),
                                                                               mode(mode)
{
    ui->setupUi(this);
    ui->pushButton->setFocus();
    ui->pushButton->setDefault(true);
    QStringList sexlist;
    sexlist << "男"
            << "女";
    ui->comboBoxSex->addItems(sexlist);
    //开启日期下拉框选项
    ui->dateEditBirthday->setCalendarPopup(true);
    ui->dateEditBirthday->setDate(QDate::currentDate());
    switch (mode)
    {
    case USER_DIALOG::CREATE:
        ui->pushButton->setText("注册");
        break;
    case USER_DIALOG::MODIFY:
        download();
        ui->lineEditID->setReadOnly(true);
        ui->pushButton->setText("更新");
        break;
    case USER_DIALOG::READONLY:
        download();
        ui->lineEditID->setReadOnly(true);
        ui->lineEditName->setReadOnly(true);
        ui->lineEditTel->setReadOnly(true);
        ui->lineEditClasses->setReadOnly(true);
        ui->lineEditCollege->setReadOnly(true);
        ui->lineEditSubject->setReadOnly(true);
        ui->comboBoxSex->setEnabled(false);
        ui->dateEditBirthday->setEnabled(false);
        ui->lineEditPassword->setVisible(false);
        ui->labelPassword->setVisible(false);
        ui->pushButton->setVisible(false);
        break;
    }
}

UserDialog::~UserDialog()
{
    delete ui;
}

void UserDialog::on_pushButton_clicked()
{
    upload();
}

void UserDialog::download()
{
    if (!id.isEmpty())
    {
        QString sql = QString("SELECT * FROM user WHERE id = '%1'")
                          .arg(id);
        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            if (query.next())
            {
                ui->lineEditID->setText(query.value(0).toString());
                ui->lineEditPassword->setText(query.value(1).toString());
                ui->lineEditName->setText(query.value(2).toString());
                ui->dateEditBirthday->setDate(query.value(3).toDate());
                ui->lineEditTel->setText(query.value(4).toString());
                ui->comboBoxSex->setCurrentText(query.value(5).toString());
                ui->lineEditClasses->setText(query.value(6).toString());
                ui->lineEditSubject->setText(query.value(7).toString());
                ui->lineEditCollege->setText(query.value(8).toString());
            }
            else
            {
                QMessageBox::warning(this, "提示", "未找到客户信息！");
            }
        }
        else
        {
            QMessageBox::warning(this, "提示", query.lastError().text());
        }
    }
}

void UserDialog::upload()
{
    QString password = ui->lineEditPassword->text().trimmed();
    QString name = ui->lineEditName->text().trimmed();
    QString birthday = ui->dateEditBirthday->date().toString("yyyy-MM-dd");
    QString tel = ui->lineEditTel->text().trimmed();
    QString sex = ui->comboBoxSex->currentText();
    QString classes = ui->lineEditClasses->text().trimmed();
    QString subject = ui->lineEditSubject->text().trimmed();
    QString college = ui->lineEditCollege->text().trimmed();

    if (password.isEmpty())
    {
        QMessageBox::warning(this, "错误提示", "请填写密码！");
        return;
    }

    if (name.isEmpty())
    {
        QMessageBox::warning(this, "错误提示", "请填写姓名！");
        return;
    }

    if (tel.isEmpty())
    {
        QMessageBox::warning(this, "错误提示", "请填写电话！");
        return;
    }

    if (classes.isEmpty())
    {
        QMessageBox::warning(this, "错误提示", "请填写班级！");
        return;
    }

    if (subject.isEmpty())
    {
        QMessageBox::warning(this, "错误提示", "请填写专业！");
        return;
    }

    if (college.isEmpty())
    {
        QMessageBox::warning(this, "错误提示", "请填写学院！");
        return;
    }

    if (mode == USER_DIALOG::CREATE)
    {
        id = ui->lineEditID->text().trimmed();
        QString sql = QString(
                          "INSERT INTO user(id, password, name, birthday, tel, sex, classes, subject, college)"
                          "VALUES('%1', '%2', '%3', '%4', '%5', '%6', '%7', '%8', '%9')")
                          .arg(id)
                          .arg(password)
                          .arg(name)
                          .arg(birthday)
                          .arg(tel)
                          .arg(sex)
                          .arg(classes)
                          .arg(subject)
                          .arg(college);

        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            QMessageBox::information(this, "提示", "注册成功");
            accept();
        }
        else
        {
            qDebug() << query.lastError().text();
            QMessageBox::warning(this, "提示", "注册失败");
        }
    }
    else
    {
        id = ui->lineEditID->text().trimmed();
        QString sql = QString(
                          "UPDATE user SET "
                          "password = '%2', "
                          "name = '%3', "
                          "birthday = '%4', "
                          "tel = '%5', "
                          "sex = '%6', "
                          "classes = '%7', "
                          "subject = '%8', "
                          "college = '%9' "
                          "WHERE id = '%1'")
                          .arg(id)
                          .arg(password)
                          .arg(name)
                          .arg(birthday)
                          .arg(tel)
                          .arg(sex)
                          .arg(classes)
                          .arg(subject)
                          .arg(college);

        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            QMessageBox::information(this, "提示", "更新成功");
            accept();
        }
        else
        {
            qDebug() << query.lastError().text();
            QMessageBox::warning(this, "提示", "更新失败");
        }
    }
}
