#include "washdialog.h"
#include "ui_washdialog.h"

WashDialog::WashDialog(QWidget *parent) : QDialog(parent),
                                          ui(new Ui::WashDialog)
{
    ui->setupUi(this);
}

WashDialog::~WashDialog()
{
    delete ui;
}
