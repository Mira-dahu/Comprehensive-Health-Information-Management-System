/*初始化数据库*/
set names utf8;
drop database if exists qt_epidemic_v4;
create database qt_epidemic_v4;
use qt_epidemic_v4;
/*建立用户信息表*/
create table admin(
  id VARCHAR(64) primary key,
  password VARCHAR(128)
);
insert into admin (id, password)
values ('admin', '123456');
create table user(
  id VARCHAR(64) primary key,
  password VARCHAR(128),
  name VARCHAR(128),
  birthday DATE,
  tel VARCHAR(128),
  sex enum('男', '女'),
  classes VARCHAR(256),
  subject VARCHAR(256),
  college VARCHAR(256)
);
insert into user(
    id,
    password,
    name,
    birthday,
    tel,
    sex,
    classes,
    subject,
    college
  )
values (
    'S001',
    '123',
    '周润发',
    '2000-1-1',
    '13000000001',
    '男',
    '三班',
    '计算机科学',
    '软件工程学院'
  ),
  (
    'S002',
    '123',
    '梁朝伟',
    '2000-2-1',
    '13000000002',
    '女',
    '三班',
    '计算机科学',
    '软件工程学院'
  ),
  (
    'S003',
    '123',
    '周星驰',
    '2000-3-1',
    '13000000003',
    '女',
    '四班',
    '结构工程',
    '土木工程学院'
  ),
  (
    'S004',
    '123',
    '刘德华',
    '2000-4-1',
    '13000000004',
    '女',
    '四班',
    '结构工程',
    '土木工程学院'
  );
/*建立业务信息表*/
create table vaccination(
  id VARCHAR(64) primary key,
  user_id VARCHAR(64),
  place VARCHAR(128),
  version VARCHAR(64),
  time DATETIME
);
create table nucleic(
  id VARCHAR(64) primary key,
  user_id VARCHAR(64),
  place VARCHAR(128),
  result VARCHAR(64),
  time DATETIME,
  img longblob
);
create table health(
  id VARCHAR(64) primary key,
  user_id VARCHAR(64),
  place VARCHAR(64),
  isolate VARCHAR(64),
  heat1 float,
  heat2 float,
  heat3 float,
  cough VARCHAR(64),
  fever VARCHAR(64),
  date DATE
);
create table route(
  id VARCHAR(64) primary key,
  user_id VARCHAR(64),
  place VARCHAR(64),
  time DATETIME
);
create table vacate(
  id VARCHAR(64) primary key,
  user_id VARCHAR(64),
  reason VARCHAR(128),
  state VARCHAR(128),
  days INT,
  time DATETIME
);
create table area(name VARCHAR(256), risk VARCHAR(256));
/*
 insert into area (name, risk)
 values ("浦东新区北蔡镇御北路235号", "中风险"),
 ("浦东新区康桥镇苗桥路935弄19号", "中风险"),
 ("闵行区华漕镇许浦村三队", "中风险"),
 ("闵行区梅陇镇行南村三队", "中风险"),
 ("崇明区长兴镇新港村15队", "中风险"),
 ("闵行区梅陇镇许泾村八组", "中风险"),
 ("嘉定区江桥镇增建村柴中村民组", "中风险"),
 ("浦东新区北蔡镇鹏飞路411弄6号", "中风险"),
 ("浦东新区北蔡镇联勤村冯桥南宅", "中风险"),
 ("嘉定区马陆镇康年路261号工地宿舍", "中风险"),
 ("浦东新区日京路88号", "中风险"),
 ("崇明区长兴镇长明村21队", "中风险"),
 ("黄浦区打浦桥街道顺昌路612弄20号", "中风险"),
 ("浦东新区其他区域", "低风险"),
 ("静安区", "低风险"),
 ("金山区其他区域", "低风险"),
 ("崇明区其他区域", "低风险"),
 ("嘉定区其他区域", "低风险"),
 ("徐汇区", "低风险"),
 ("闵行区其他区域", "低风险"),
 ("黄浦区其他区域", "低风险"),
 ("松江区", "低风险"),
 ("普陀区", "低风险"),
 ("奉贤区", "低风险"),
 ("青浦区", "低风险"),
 ("杨浦区", "低风险"),
 ("虹口区", "低风险"),
 ("长宁区", "低风险"),
 ("宝山区", "低风险");
 */
insert into area (name, risk)
values ("哈尔滨市 南岗区 王岗镇", "高风险"),
  ("哈尔滨市 南岗区 跃进街道全域", "高风险"),
  ("牡丹江市 爱民区 拥军社区", "中风险"),
  ("哈尔滨市 香坊区 朝阳镇前进村居民区", "中风险"),
  ("哈尔滨市 香坊区 朝阳镇永胜村居民区", "中风险"),
  ("哈尔滨市 香坊区 新香坊街道办事处金源蓝城小区11号楼", "中风险"),
  ("哈尔滨市 香坊区 朝阳镇平安村居民区", "中风险"),
  ("哈尔滨市 道里区 城乡路街道汇智广场B座（东方大街与规划路交叉口）", "中风险"),
  ("哈尔滨市 道里区 城乡路街道悦庭清湾小区（顾新路497号）", "中风险"),
  ("哈尔滨市 道里区 群力新苑小区C区（工农大街625号）", "中风险"),
  ("哈尔滨市 双城区 承旭街道社保局东边胡同平房片区", "中风险"),
  ("哈尔滨市 双城区 永治街道团结大街235号幸福e家1栋", "中风险"),
  ("哈尔滨市 双城区 幸福街道庆宁村", "中风险"),
  ("哈尔滨市 双城区 永治街道奋斗社区温馨小区1栋", "中风险"),
  ("哈尔滨市 双城区 乐群满族乡乐民村", "中风险"),
  ("哈尔滨市 双城区 永治街道车站街一委四组", "中风险"),
  ("哈尔滨市 双城区 永治街道天富名苑小区", "中风险"),
  ("哈尔滨市 双城区 永治街道洗涤剂家属楼小区", "中风险"),
  ("哈尔滨市 双城区 永治街道财富名苑小区", "中风险"),
  ("哈尔滨市 双城区 永治街道民乐小区B区", "中风险"),
  ("哈尔滨市 双城区 永治街道明城华都5栋", "中风险"),
  ("哈尔滨市 双城区 永治街道鑫马家园小区", "中风险"),
  ("哈尔滨市 双城区 承恩街道承恩村六组二委", "中风险"),
  ("哈尔滨市 双城区 承旭街道党校家属楼小区", "中风险"),
  ("哈尔滨市 双城区 幸福街道永支村", "中风险"),
  ("哈尔滨市 双城区 联兴镇安乐村", "中风险"),
  ("哈尔滨市 双城区 承旭街道枫桥郡小区", "中风险"),
  ("哈尔滨市 双城区 律政花园", "中风险"),
  ("哈尔滨市 双城区 金园一品小区2栋", "中风险"),
  ("哈尔滨市 双城区 金园一品小区4栋", "中风险"),
  ("哈尔滨市 南岗区 文汇家园小区1栋", "中风险"),
  ("哈尔滨市 南岗区 上夹树街75号院", "中风险"),
  ("哈尔滨市 南岗区 大众新城220栋", "中风险"),
  ("哈尔滨市 南岗区 海城街176号院", "中风险"),
  ("哈尔滨市 南岗区 新境街10号新华印刷厂家属楼小区10栋", "中风险");
insert into vacate(id, user_id, reason, state, days, time)
values (
    UUID(),
    "S001",
    "回家探亲",
    "审核中",
    3,
    '2022-5-8 16:11'
  );