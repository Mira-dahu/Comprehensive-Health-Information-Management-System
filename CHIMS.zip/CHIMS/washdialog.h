#ifndef WASHDIALOG_H
#define WASHDIALOG_H

#include <QDialog>

namespace Ui
{
    class WashDialog;
}

class WashDialog : public QDialog
{
    Q_OBJECT

public:
    explicit WashDialog(QWidget *parent = nullptr);
    ~WashDialog();

private:
    Ui::WashDialog *ui;
};

#endif // WASHDIALOG_H
