#include "nucleicdialog.h"
#include "ui_nucleicdialog.h"
#include <QFileDialog>
#include <QBuffer>
#include <QImage>
#include <QPixmap>
#include <QVariant>
#include <QMessageBox>
#include <QDate>
#include <QSqlError>
#include <QDebug>

NucleicDialog::NucleicDialog(const QString &id, const QString &user_id, NUCLEIC_DIALOG mode, QWidget *parent) : QDialog(parent),
                                                                                                                ui(new Ui::NucleicDialog),
                                                                                                                id(id),
                                                                                                                user_id(user_id),
                                                                                                                mode(mode)
{
    ui->setupUi(this);
    ui->labelImg->setStyleSheet("QLabel{background:#ffffff;}");
    setWindowTitle("核酸检测信息");
    ui->dateTimeEdit->setCalendarPopup(true);
    ui->dateTimeEdit->setDateTime(QDateTime::currentDateTime());
    ui->pushButton->setDefault(true);
    ui->lineEditID->setReadOnly(true);
    ui->lineEditUserName->setReadOnly(true);

    QStringList list;
    list << "阴性"
         << "阳性"
         << "可疑";

    ui->comboBoxResult->addItems(list);

    switch (mode)
    {
    case NUCLEIC_DIALOG::CREATE:
        ui->labelID->setVisible(false);
        ui->lineEditID->setVisible(false);
        ui->pushButton->setText("提交");
        break;
    case NUCLEIC_DIALOG::MODIFY:
        ui->pushButton->setText("更新");
        ui->lineEditID->setReadOnly(true);
        ui->lineEditUserID->setReadOnly(true);
        break;
    case NUCLEIC_DIALOG::READONLY:
        ui->pushButton->setVisible(false);
        ui->lineEditID->setReadOnly(true);
        ui->lineEditPlace->setReadOnly(true);
        ui->lineEditUserID->setReadOnly(true);
        ui->comboBoxResult->setEnabled(false);
        ui->dateTimeEdit->setEnabled(false);
        break;
    }
    download();
}

NucleicDialog::~NucleicDialog()
{
    delete ui;
}

void NucleicDialog::on_pushButton_clicked()
{
    if (check())
    {
        upload();
    }
}

void NucleicDialog::on_pushButtonImage_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this,
                                                    tr("打开图片"), "./", tr("Image Files (*.png *.jpg *.bmp)"));
    if (!fileName.isEmpty())
    {
        QImage image;
        image.load(fileName);
        QImage result = image.scaled(ui->labelImg->width(), ui->labelImg->height(),
                                     Qt::KeepAspectRatio, Qt::SmoothTransformation);
        ui->labelImg->setPixmap(QPixmap::fromImage(result));
        imagefile = fileName;
    }
}

void NucleicDialog::download()
{
    if (!user_id.isEmpty())
    {
        ui->lineEditUserID->setReadOnly(true);
        ui->lineEditUserID->setText(user_id);
        QString sql = QString("SELECT name FROM user WHERE id = '%1'")
                          .arg(user_id);
        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            if (query.next())
            {
                ui->lineEditUserName->setText(query.value(0).toString());
            }
            else
            {
                QMessageBox::warning(this, "提示", "未找到客户信息！");
            }
        }
        else
        {
            QMessageBox::warning(this, "提示", query.lastError().text());
        }
    }

    if (!id.isEmpty())
    {
        QString sql = QString("SELECT * FROM nucleic WHERE nucleic.id = '%1'")
                          .arg(id);
        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            if (query.next())
            {
                ui->lineEditID->setText(query.value(0).toString());
                ui->lineEditUserID->setText(query.value(1).toString());
                ui->lineEditPlace->setText(query.value(2).toString());
                ui->comboBoxResult->setCurrentText(query.value(3).toString());
                ui->dateTimeEdit->setDateTime(query.value(4).toDateTime());

                QPixmap pixmap;
                pixmap.loadFromData(query.value(5).toByteArray(), "PNG");
                ui->labelImg->setPixmap(pixmap);
            }
            else
            {
                QMessageBox::warning(this, "提示", "未找到信息！");
            }
        }
        else
        {
            QMessageBox::warning(this, "提示", query.lastError().text());
        }
    }
}

void NucleicDialog::upload()
{
    QString place = ui->lineEditPlace->text().trimmed();
    QString result = ui->comboBoxResult->currentText().trimmed();
    QString time = ui->dateTimeEdit->dateTime().toString("yyyy-MM-dd hh:mm:ss");

    if (place.isEmpty())
    {
        QMessageBox::warning(this, "错误提示", "请填写测试地点！");
        return;
    }

    if (imagefile.isEmpty())
    {
        QMessageBox::warning(this, "提示", "请上传图片！");
        return;
    }

    if (mode == NUCLEIC_DIALOG::CREATE)
    {
        QImage image;
        image.load(imagefile);
        image = image.scaled(ui->labelImg->width(), ui->labelImg->height(),
                             Qt::KeepAspectRatio, Qt::SmoothTransformation);

        QPixmap pixmap = QPixmap::fromImage(image);
        QByteArray bytes;
        QBuffer buffer(&bytes);
        buffer.open(QIODevice::WriteOnly);
        pixmap.save(&buffer, "PNG");
        QVariant imageData(bytes);

        user_id = ui->lineEditUserID->text().trimmed();
        QString sql = QString(
                          "INSERT INTO nucleic(id, user_id, place, result, time, img)"
                          "VALUES(UUID(), '%1', '%2', '%3', '%4', ?)")
                          .arg(user_id)
                          .arg(place)
                          .arg(result)
                          .arg(time);

        QSqlQuery query = runtime.getDBManager().query();
        query.prepare(sql);
        query.addBindValue(imageData);
        if (query.exec())
        {
            QMessageBox::information(this, "提示", "提交成功");
            accept();
        }
        else
        {
            qDebug() << query.lastError().text();
            QMessageBox::warning(this, "提示", "提交失败");
        }
    }
    else
    {
        if (!imagefile.isEmpty())
        {
            QImage image;
            image.load(imagefile);
            QImage result = image.scaled(ui->labelImg->width(), ui->labelImg->height(),
                                         Qt::KeepAspectRatio, Qt::SmoothTransformation);

            QPixmap pixmap = QPixmap::fromImage(result);
            QByteArray bytes;
            QBuffer buffer(&bytes);
            buffer.open(QIODevice::WriteOnly);
            pixmap.save(&buffer, "PNG");
            QVariant imageData(bytes);

            QString sql = QString("UPDATE nucleic SET img = ? WHERE id = '%1'")
                              .arg(id);

            QSqlQuery query = runtime.getDBManager().query();

            query.prepare(sql);
            query.addBindValue(imageData);
            if (!query.exec())
            {
                QMessageBox::warning(this, "提示", "图标更新失败！");
            }
        }

        id = ui->lineEditID->text().trimmed();
        QString sql = QString(
                          "UPDATE nucleic SET "
                          "place = '%2', "
                          "result = '%3', "
                          "time = '%4' "
                          "WHERE id = '%1'")
                          .arg(id)
                          .arg(place)
                          .arg(result)
                          .arg(time);

        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            QMessageBox::information(this, "提示", "更新成功");
            accept();
        }
        else
        {
            qDebug() << query.lastError().text();
            QMessageBox::warning(this, "提示", "更新失败");
        }
    }
}

bool NucleicDialog::check()
{
    user_id = ui->lineEditUserID->text().trimmed();
    if (!user_id.isEmpty())
    {
        QString sql = QString("SELECT count(*) FROM user WHERE id = '%1'")
                          .arg(user_id);
        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            if (query.next() && query.value(0).toInt() == 0)
            {
                QMessageBox::warning(this, "提示", "未找到客户信息！");
                return false;
            }
        }
        else
        {
            QMessageBox::warning(this, "提示", query.lastError().text());
        }
    }
    return true;
}
