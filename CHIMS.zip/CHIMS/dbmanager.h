#ifndef DBMANAGER_H
#define DBMANAGER_H

#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QString>
#include <QObject>

class DBManager
{
public:
    DBManager();

public:
    void check();
    bool start(const QString &host_ip, int host_port, const QString &db_name, const QString &db_user_id, const QString &db_user_password);
    QSqlQuery query();
    QSqlDatabase &getDB();

private:
    QSqlDatabase db;
};

#endif // SQLMANAGER_H
