#include "vaccinationdialog.h"
#include "ui_vaccinationdialog.h"
#include <QMessageBox>
#include <QDateTime>
#include <QSqlError>
#include <QDebug>

VaccinationDialog::VaccinationDialog(const QString &id, const QString &user_id, VACCINATION_DIALOG mode, QWidget *parent) : QDialog(parent),
                                                                                                                            ui(new Ui::VaccinationDialog),
                                                                                                                            id(id),
                                                                                                                            user_id(user_id),
                                                                                                                            mode(mode)
{
    ui->setupUi(this);
    setWindowTitle("疫苗接种信息");
    ui->dateTimeEdit->setCalendarPopup(true);
    ui->dateTimeEdit->setDateTime(QDateTime::currentDateTime());
    ui->pushButton->setDefault(true);
    ui->lineEditID->setReadOnly(true);
    ui->lineEditUserName->setReadOnly(true);

    QStringList list;
    list << "第一针"
         << "第二针"
         << "第三针";

    ui->comboBoxVersion->addItems(list);

    switch (mode)
    {
    case VACCINATION_DIALOG::CREATE:
        ui->labelID->setVisible(false);
        ui->lineEditID->setVisible(false);
        ui->pushButton->setText("提交");
        break;
    case VACCINATION_DIALOG::MODIFY:
        ui->pushButton->setText("更新");
        ui->lineEditID->setReadOnly(true);
        ui->lineEditUserID->setReadOnly(true);
        break;
    case VACCINATION_DIALOG::READONLY:
        ui->pushButton->setVisible(false);
        ui->lineEditID->setReadOnly(true);
        ui->lineEditPlace->setReadOnly(true);
        ui->lineEditUserID->setReadOnly(true);
        ui->comboBoxVersion->setEnabled(false);
        ui->dateTimeEdit->setEnabled(false);
        break;
    }
    download();
}

VaccinationDialog::~VaccinationDialog()
{
    delete ui;
}

void VaccinationDialog::on_pushButton_clicked()
{
    if (check())
    {
        upload();
    }
}

void VaccinationDialog::download()
{
    if (!user_id.isEmpty())
    {
        ui->lineEditUserID->setReadOnly(true);
        ui->lineEditUserID->setText(user_id);
        QString sql = QString("SELECT name FROM user WHERE id = '%1'")
                          .arg(user_id);
        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            if (query.next())
            {
                ui->lineEditUserName->setText(query.value(0).toString());
            }
            else
            {
                QMessageBox::warning(this, "提示", "未找到客户信息！");
            }
        }
        else
        {
            QMessageBox::warning(this, "提示", query.lastError().text());
        }
    }

    if (!id.isEmpty())
    {
        QString sql = QString("SELECT * FROM vaccination WHERE vaccination.id = '%1'")
                          .arg(id);
        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            if (query.next())
            {
                ui->lineEditID->setText(query.value(0).toString());
                ui->lineEditUserID->setText(query.value(1).toString());
                ui->lineEditPlace->setText(query.value(2).toString());
                ui->comboBoxVersion->setCurrentText(query.value(3).toString());
                ui->dateTimeEdit->setDateTime(query.value(4).toDateTime());
            }
            else
            {
                QMessageBox::warning(this, "提示", "未找到信息！");
            }
        }
        else
        {
            QMessageBox::warning(this, "提示", query.lastError().text());
        }
    }
}

void VaccinationDialog::upload()
{
    QString place = ui->lineEditPlace->text().trimmed();
    QString version = ui->comboBoxVersion->currentText().trimmed();
    QString time = ui->dateTimeEdit->dateTime().toString("yyyy-MM-dd hh:mm:ss");

    if (place.isEmpty())
    {
        QMessageBox::warning(this, "错误提示", "请填写接种地点！");
        return;
    }

    if (mode == VACCINATION_DIALOG::CREATE)
    {
        user_id = ui->lineEditUserID->text().trimmed();
        QString sql = QString(
                          "INSERT INTO vaccination(id, user_id, place, version, time)"
                          "VALUES(UUID(), '%1', '%2', '%3', '%4')")
                          .arg(user_id)
                          .arg(place)
                          .arg(version)
                          .arg(time);

        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            QMessageBox::information(this, "提示", "提交成功");
            accept();
        }
        else
        {
            qDebug() << query.lastError().text();
            QMessageBox::warning(this, "提示", "提交失败");
        }
    }
    else
    {
        id = ui->lineEditID->text().trimmed();
        QString sql = QString(
                          "UPDATE vaccination SET "
                          "place = '%2', "
                          "version = '%3', "
                          "time = '%4' "
                          "WHERE id = '%1'")
                          .arg(id)
                          .arg(place)
                          .arg(version)
                          .arg(time);

        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            QMessageBox::information(this, "提示", "更新成功");
            accept();
        }
        else
        {
            qDebug() << query.lastError().text();
            QMessageBox::warning(this, "提示", "更新失败");
        }
    }
}

bool VaccinationDialog::check()
{
    user_id = ui->lineEditUserID->text().trimmed();
    if (!user_id.isEmpty())
    {
        QString sql = QString("SELECT count(*) FROM user WHERE id = '%1'")
                          .arg(user_id);
        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            if (query.next() && query.value(0).toInt() == 0)
            {
                QMessageBox::warning(this, "提示", "未找到客户信息！");
                return false;
            }
        }
        else
        {
            QMessageBox::warning(this, "提示", query.lastError().text());
        }
    }

    if (!user_id.isEmpty())
    {
        QString sql = QString("SELECT count(*) FROM "
                              "vaccination "
                              "WHERE user_id = '%1' "
                              "AND version = '%2'")
                          .arg(user_id)
                          .arg(ui->comboBoxVersion->currentText());
        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            if (query.next() && query.value(0).toInt() > 0)
            {
                QMessageBox::warning(this, "提示", "数据已存在！");
                return false;
            }
        }
        else
        {
            QMessageBox::warning(this, "提示", query.lastError().text());
        }
    }

    return true;
}
