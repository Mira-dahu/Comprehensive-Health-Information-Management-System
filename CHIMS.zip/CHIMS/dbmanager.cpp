#include "dbmanager.h"

#include <QMessageBox>
#include <QSqlError>
#include <QDebug>

DBManager::DBManager()
{
}

void DBManager::check()
{
    if (db.drivers().indexOf("QMYSQL") == -1)
    {
        QMessageBox::critical(nullptr, "严重错误", "MySQL driver驱动未配置！");
        exit(-1);
    }
}

bool DBManager::start(const QString &host_ip, int host_port, const QString &db_name, const QString &db_user_id, const QString &db_user_password)
{
    if (!QSqlDatabase::contains("ConnectDB"))
    {
        db = QSqlDatabase::addDatabase("QMYSQL", "ConnectDB");
    }
    db.setHostName(host_ip);
    db.setPort(host_port);
    db.setDatabaseName(db_name);
    db.setUserName(db_user_id);
    db.setPassword(db_user_password);
    bool succeed = db.open();
    if (!succeed)
    {
        QMessageBox::warning(nullptr, "连接数据库失败", db.lastError().text());
    }
    return succeed;
}

QSqlQuery DBManager::query()
{
    return QSqlQuery(db);
}

QSqlDatabase &DBManager::getDB()
{
    return db;
}
