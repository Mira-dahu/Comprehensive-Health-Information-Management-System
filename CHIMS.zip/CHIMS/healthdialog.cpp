#include "healthdialog.h"
#include "ui_healthdialog.h"
#include <QMessageBox>
#include <QDate>
#include <QSqlError>
#include <QDebug>

HealthDialog::HealthDialog(const QString &id, const QString &user_id, HEALTH_DIALOG mode, QWidget *parent) : QDialog(parent),
                                                                                                             ui(new Ui::HealthDialog),
                                                                                                             id(id),
                                                                                                             user_id(user_id),
                                                                                                             mode(mode)
{
    ui->setupUi(this);
    setWindowTitle("健康打卡信息");
    ui->dateEdit->setCalendarPopup(true);
    ui->dateEdit->setDate(QDate::currentDate());
    ui->pushButton->setDefault(true);
    ui->lineEditID->setReadOnly(true);
    ui->lineEditUserName->setReadOnly(true);
    ui->lineEditHeat1->setValidator(new QDoubleValidator(34, 45, 2, this));
    ui->lineEditHeat2->setValidator(new QDoubleValidator(34, 45, 2, this));
    ui->lineEditHeat3->setValidator(new QDoubleValidator(34, 45, 2, this));

    QStringList yesno;
    yesno << "否"
          << "是";

    ui->comboBoxCough->addItems(yesno);
    ui->comboBoxFever->addItems(yesno);
    ui->comboBoxIsolate->addItems(yesno);

    QStringList list;
    list << "疫区"
         << "本市"
         << "学校";

    ui->comboBoxPlace->addItems(list);

    switch (mode)
    {
    case HEALTH_DIALOG::CREATE:
        ui->labelID->setVisible(false);
        ui->lineEditID->setVisible(false);
        ui->pushButton->setText("提交");
        break;
    case HEALTH_DIALOG::MODIFY:
        ui->pushButton->setText("更新");
        ui->lineEditID->setReadOnly(true);
        ui->lineEditUserID->setReadOnly(true);
        break;
    case HEALTH_DIALOG::READONLY:
        ui->pushButton->setVisible(false);
        ui->lineEditID->setReadOnly(true);
        ui->lineEditUserID->setReadOnly(true);
        ui->lineEditHeat1->setReadOnly(true);
        ui->lineEditHeat2->setReadOnly(true);
        ui->lineEditHeat3->setReadOnly(true);
        ui->comboBoxCough->setEnabled(false);
        ui->comboBoxFever->setEnabled(false);
        ui->dateEdit->setEnabled(false);
        break;
    }
    download();
}

HealthDialog::~HealthDialog()
{
    delete ui;
}

void HealthDialog::on_pushButton_clicked()
{
    if (check())
    {
        upload();
    }
}

void HealthDialog::download()
{
    if (!user_id.isEmpty())
    {
        ui->lineEditUserID->setReadOnly(true);
        ui->lineEditUserID->setText(user_id);
        QString sql = QString("SELECT name FROM user WHERE id = '%1'")
                          .arg(user_id);
        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            if (query.next())
            {
                ui->lineEditUserName->setText(query.value(0).toString());
            }
            else
            {
                QMessageBox::warning(this, "提示", "未找到客户信息！");
            }
        }
        else
        {
            QMessageBox::warning(this, "提示", query.lastError().text());
        }
    }

    if (!id.isEmpty())
    {
        QString sql = QString("SELECT * FROM health WHERE health.id = '%1'")
                          .arg(id);
        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            if (query.next())
            {
                ui->lineEditID->setText(query.value(0).toString());
                ui->lineEditUserID->setText(query.value(1).toString());
                ui->lineEditHeat1->setText(query.value(4).toString());
                ui->lineEditHeat2->setText(query.value(5).toString());
                ui->lineEditHeat3->setText(query.value(6).toString());
                ui->comboBoxCough->setCurrentText(query.value(7).toString());
                ui->comboBoxFever->setCurrentText(query.value(8).toString());
                ui->dateEdit->setDateTime(query.value(9).toDateTime());
                ui->comboBoxPlace->setCurrentText(query.value(2).toString());
                ui->comboBoxIsolate->setCurrentText(query.value(3).toString());
            }
            else
            {
                QMessageBox::warning(this, "提示", "未找到信息！");
            }
        }
        else
        {
            QMessageBox::warning(this, "提示", query.lastError().text());
        }
    }
}

void HealthDialog::upload()
{
    QString place = ui->comboBoxPlace->currentText();
    QString isolate = ui->comboBoxIsolate->currentText();
    QString heat1 = ui->lineEditHeat1->text().trimmed();
    QString heat2 = ui->lineEditHeat2->text().trimmed();
    QString heat3 = ui->lineEditHeat3->text().trimmed();
    QString cough = ui->comboBoxCough->currentText().trimmed();
    QString fever = ui->comboBoxFever->currentText().trimmed();
    QString date = ui->dateEdit->dateTime().toString("yyyy-MM-dd");

    if (heat1.isEmpty())
    {
        QMessageBox::warning(this, "错误提示", "请填写体温（上午）！");
        return;
    }

    if (heat2.isEmpty())
    {
        QMessageBox::warning(this, "错误提示", "请填写体温（下午）！");
        return;
    }

    if (heat3.isEmpty())
    {
        QMessageBox::warning(this, "错误提示", "请填写体温（晚上）！");
        return;
    }

    if (mode == HEALTH_DIALOG::CREATE)
    {
        user_id = ui->lineEditUserID->text().trimmed();
        QString sql = QString(
                          "INSERT INTO health(id, user_id, place, isolate, heat1, heat2, heat3, cough, fever, date)"
                          "VALUES(UUID(), '%1', '%2', '%3', %4, %5, %6, '%7', '%8', '%9')")
                          .arg(user_id)
                          .arg(place)
                          .arg(isolate)
                          .arg(heat1.toDouble())
                          .arg(heat2.toDouble())
                          .arg(heat3.toDouble())
                          .arg(cough)
                          .arg(fever)
                          .arg(date);

        qDebug() << sql;

        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            QMessageBox::information(this, "提示", "提交成功");
            accept();
        }
        else
        {
            qDebug() << query.lastError().text();
            QMessageBox::warning(this, "提示", "提交失败");
        }
    }
    else
    {
        id = ui->lineEditID->text().trimmed();
        QString sql = QString(
                          "UPDATE health SET "
                          "user_id = '%2', "
                          "place = '%3', "
                          "isolate = '%4', "
                          "heat1 = %5, "
                          "heat2 = %6, "
                          "heat3 = %7, "
                          "cough = '%8', "
                          "fever = '%9', "
                          "date = '%10' "
                          "WHERE id = '%1'")
                          .arg(id)
                          .arg(user_id)
                          .arg(place)
                          .arg(isolate)
                          .arg(heat1.toDouble())
                          .arg(heat2.toDouble())
                          .arg(heat3.toDouble())
                          .arg(cough)
                          .arg(fever)
                          .arg(date);

        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            QMessageBox::information(this, "提示", "更新成功");
            accept();
        }
        else
        {
            qDebug() << query.lastError().text();
            QMessageBox::warning(this, "提示", "更新失败");
        }
    }
}

bool HealthDialog::check()
{
    user_id = ui->lineEditUserID->text().trimmed();
    if (!user_id.isEmpty())
    {
        QString sql = QString("SELECT count(*) FROM user WHERE id = '%1'")
                          .arg(user_id);
        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            if (query.next() && query.value(0).toInt() == 0)
            {
                QMessageBox::warning(this, "提示", "未找到客户信息！");
                return false;
            }
        }
        else
        {
            QMessageBox::warning(this, "提示", query.lastError().text());
        }
    }

    if (!user_id.isEmpty())
    {
        QString date = ui->dateEdit->dateTime().toString("yyyy-MM-dd");
        QString sql = QString("SELECT count(*) FROM "
                              "health "
                              "WHERE user_id = '%1' "
                              "AND DATE_FORMAT(date,'%Y-%m-%d') = '%2'")
                          .arg(user_id)
                          .arg(date);
        QSqlQuery query = runtime.getDBManager().query();
        if (query.exec(sql))
        {
            if (query.next() && query.value(0).toInt() > 0)
            {
                int count = query.value(0).toInt();
                if (mode == HEALTH_DIALOG::CREATE && count > 0)
                {
                    QMessageBox::warning(this, "提示", "数据已存在！");
                    return false;
                }
                if (count > 1)
                {
                    QMessageBox::warning(this, "提示", "数据已存在！");
                    return false;
                }
            }
        }
        else
        {
            QMessageBox::warning(this, "提示", query.lastError().text());
        }
    }
}
